<?php
namespace Admin\View\Helper;
class FormHelper extends \Cake\View\Helper\FormHelper
{
  use FormCspHelperTrait;
}